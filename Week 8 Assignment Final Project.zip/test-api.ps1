# ==============================
# Clinic API Test Script (PowerShell)
# ==============================

$baseUrl = "http://localhost:3000"

Write-Host ""
Write-Host "=== Testing Clinic API at $baseUrl ===" -ForegroundColor Cyan
Write-Host ""

# -----------------------------
# 1. GET all patients
# -----------------------------
Write-Host "GET /patients" -ForegroundColor Yellow
curl.exe -s "$baseUrl/patients" | ConvertFrom-Json | Format-Table -AutoSize
Write-Host ""

# -----------------------------
# 2. POST new patient
# -----------------------------
Write-Host "POST /patients (adding new patient...)" -ForegroundColor Yellow

$newPatient = @{
    first_name    = "Jane"
    last_name     = "Smith"
    date_of_birth = "1992-03-12"
    phone_number  = "5551234567"
    email         = "jane.smith@example.com"
}

Invoke-RestMethod -Uri "$baseUrl/patients" `
    -Method POST `
    -Headers @{ "Content-Type" = "application/json" } `
    -Body ($newPatient | ConvertTo-Json)

Write-Host "✔ Patient created" -ForegroundColor Green
Write-Host ""

# -----------------------------
# 3. GET patients again
# -----------------------------
Write-Host "GET /patients (after insert)" -ForegroundColor Yellow
curl.exe -s "$baseUrl/patients" | ConvertFrom-Json | Format-Table -AutoSize
Write-Host ""
