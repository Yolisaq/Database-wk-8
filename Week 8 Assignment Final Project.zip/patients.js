const express = require('express');
const router = express.Router();
const db = require('./db');

// Get all patients
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM Patients');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get a patient by ID
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM Patients WHERE patient_id = ?', [req.params.id]);
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Create a new patient
router.post('/', async (req, res) => {
    const { first_name, last_name, date_of_birth, phone_number, email } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO Patients (first_name, last_name, date_of_birth, phone_number, email) VALUES (?, ?, ?, ?, ?)',
            [first_name, last_name, date_of_birth, phone_number, email]
        );
        res.json({ patient_id: result.insertId, first_name, last_name, date_of_birth, phone_number, email });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update a patient
router.put('/:id', async (req, res) => {
    const { first_name, last_name, date_of_birth, phone_number, email } = req.body;
    try {
        await db.query(
            'UPDATE Patients SET first_name = ?, last_name = ?, date_of_birth = ?, phone_number = ?, email = ? WHERE patient_id = ?',
            [first_name, last_name, date_of_birth, phone_number, email, req.params.id]
        );
        res.json({ message: 'Patient updated successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Delete a patient
router.delete('/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM Patients WHERE patient_id = ?', [req.params.id]);
        res.json({ message: 'Patient deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
