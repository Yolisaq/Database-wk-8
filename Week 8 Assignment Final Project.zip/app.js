const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
const patientsRoutes = require('./patients');
const appointmentsRoutes = require('./appointments');

app.use('/patients', patientsRoutes);
app.use('/appointments', appointmentsRoutes);

// Root endpoint
app.get('/', (req, res) => {
    res.send('Clinic Booking System API is running');
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
