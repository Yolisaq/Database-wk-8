const express = require('express');
const router = express.Router();
const db = require('../db');

// Create Prescription
router.post('/', async (req, res) => {
    const { appointment_id, medication, dosage, duration } = req.body;
    try {
        await db.query(
            'INSERT INTO Prescriptions (appointment_id, medication, dosage, duration) VALUES (?, ?, ?, ?)',
            [appointment_id, medication, dosage, duration]
        );
        res.send('Prescription added successfully');
    } catch (err) {
        res.status(500).send(err);
    }
});

// Read Prescriptions
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT pr.prescription_id, pr.medication, pr.dosage, pr.duration,
                   a.appointment_date, p.first_name AS patient_first_name, p.last_name AS patient_last_name
            FROM Prescriptions pr
            JOIN Appointments a ON pr.appointment_id = a.appointment_id
            JOIN Patients p ON a.patient_id = p.patient_id
        `);
        res.json(rows);
    } catch (err) {
        res.status(500).send(err);
    }
});

module.exports = router;
