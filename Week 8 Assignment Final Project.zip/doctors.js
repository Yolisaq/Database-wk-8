const express = require('express');
const router = express.Router();
const db = require('../db');

// Create Doctor
router.post('/', async (req, res) => {
    const { first_name, last_name, specialty, phone_number, email } = req.body;
    try {
        await db.query(
            'INSERT INTO Doctors (first_name, last_name, specialty, phone_number, email) VALUES (?, ?, ?, ?, ?)',
            [first_name, last_name, specialty, phone_number, email]
        );
        res.send('Doctor added successfully');
    } catch (err) {
        res.status(500).send(err);
    }
});

// Read Doctors
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM Doctors');
        res.json(rows);
    } catch (err) {
        res.status(500).send(err);
    }
});

// Update Doctor
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { first_name, last_name, specialty, phone_number, email } = req.body;
    try {
        await db.query(
            'UPDATE Doctors SET first_name=?, last_name=?, specialty=?, phone_number=?, email=? WHERE doctor_id=?',
            [first_name, last_name, specialty, phone_number, email, id]
        );
        res.send('Doctor updated successfully');
    } catch (err) {
        res.status(500).send(err);
    }
});

// Delete Doctor
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await db.query('DELETE FROM Doctors WHERE doctor_id=?', [id]);
        res.send('Doctor deleted successfully');
    } catch (err) {
        res.status(500).send(err);
    }
});

module.exports = router;
