const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Import routes
const patientsRoutes = require('./routes/patients');
const doctorsRoutes = require('./routes/doctors');
const appointmentsRoutes = require('./routes/appointments');
const prescriptionsRoutes = require('./routes/prescriptions');
const insuranceRoutes = require('./routes/insurance');

// Use routes
app.use('/patients', patientsRoutes);
app.use('/doctors', doctorsRoutes);
app.use('/appointments', appointmentsRoutes);
app.use('/prescriptions', prescriptionsRoutes);
app.use('/insurance', insuranceRoutes);

// Start server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
