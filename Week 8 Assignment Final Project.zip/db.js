const mysql = require('mysql2/promise');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',           // your MySQL user
    password: 'LisaQ96#@!', // your MySQL password
    database: 'ClinicDB',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = db;
