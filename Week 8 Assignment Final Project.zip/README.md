# Clinic Booking System CRUD API

## Running the App
1. Install dependencies: `npm install`
2. Run server: `node app.js`
3. MySQL database must be running locally with ClinicDB schema.

## API Endpoints

### Patients
- `POST /patients` – Add new patient
- `GET /patients` – List all patients
- `PUT /patients/:id` – Update patient
- `DELETE /patients/:id` – Delete patient

### Appointments
- `POST /appointments` – Schedule new appointment
- `GET /appointments` – List all appointments with patient and doctor names
- `PUT /appointments/:id` – Update appointment
- `DELETE /appointments/:id` – Cancel appointment
