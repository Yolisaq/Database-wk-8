const express = require('express');
const router = express.Router();
const db = require('./db');

// Get all appointments
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT a.*, p.first_name AS patient_first_name, p.last_name AS patient_last_name, 
                    d.first_name AS doctor_first_name, d.last_name AS doctor_last_name
             FROM Appointments a
             JOIN Patients p ON a.patient_id = p.patient_id
             JOIN Doctors d ON a.doctor_id = d.doctor_id`
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get appointment by ID
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM Appointments WHERE appointment_id = ?', [req.params.id]);
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Create a new appointment
router.post('/', async (req, res) => {
    const { patient_id, doctor_id, appointment_date, reason, status } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO Appointments (patient_id, doctor_id, appointment_date, reason, status) VALUES (?, ?, ?, ?, ?)',
            [patient_id, doctor_id, appointment_date, reason, status]
        );
        res.json({ appointment_id: result.insertId, patient_id, doctor_id, appointment_date, reason, status });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update appointment
router.put('/:id', async (req, res) => {
    const { patient_id, doctor_id, appointment_date, reason, status } = req.body;
    try {
        await db.query(
            'UPDATE Appointments SET patient_id = ?, doctor_id = ?, appointment_date = ?, reason = ?, status = ? WHERE appointment_id = ?',
            [patient_id, doctor_id, appointment_date, reason, status, req.params.id]
        );
        res.json({ message: 'Appointment updated successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Delete appointment
router.delete('/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM Appointments WHERE appointment_id = ?', [req.params.id]);
        res.json({ message: 'Appointment deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
